# ASAWA and Co. eCommerce Platform

This repository contains a full‑stack eCommerce platform for **ASAWA and Co.** built with **React/Next.js** on the front‑end and **Node.js/Express** with **MySQL** on the back‑end.  The goal of the project is to deliver a modern, high‑performance, SEO‑optimized shopping experience with a comprehensive admin dashboard, inventory management, GRN (Goods Receipt Note) functionality, billing/POS screens and automatic PDF invoice generation.

## Monorepo Structure

The codebase is organized into two main folders:

* **`backend/`** – Express application, database models, routes, controllers and configuration files.  All interactions with MySQL are handled here.  Authentication is implemented using JWT and bcrypt.  Email notifications are sent via Nodemailer using Gmail SMTP.
* **`frontend/`** – Next.js application implementing the customer‑facing storefront and basic user account pages.  Components are styled with TailwindCSS and animations leverage Framer Motion.  The `_document.js` file contains the Google Analytics integration; replace the measurement ID with your own.

Additionally there is a SQL migration file under **`backend/sql/schema.sql`** that creates all required database tables.  This file can be executed against an empty MySQL database to provision the schema.

## Getting Started

1. **Install Dependencies**

   ```bash
   # From the repository root
   cd backend && npm install
   cd ../frontend && npm install
   ```

2. **Configure Environment Variables**

   Duplicate `.env.example` as `.env` in the `backend` folder and fill in your MySQL credentials, JWT secret and mailer settings.  For the front‑end, copy `.env.example` to `.env.local` and provide a valid API URL and Google Analytics measurement ID.

3. **Run the Development Servers**

   ```bash
   # Backend API
   cd backend
   npm run dev

   # Frontend
   cd ../frontend
   npm run dev
   ```

4. **Database Migration**

   Before starting the server, import `backend/sql/schema.sql` into your MySQL server.  This will create the necessary tables for users, products, orders, inventory, GRNs, invoices, blogs, CMS pages, coupons and more.

5. **Notes**

* This project is a starting point.  It includes foundational pages and API endpoints but leaves room for further customization.  You can extend the controllers and React components to implement advanced features such as PDF invoice generation, rich product filtering, and POS barcode scanning.
* All credentials and secrets in this repository are placeholders.  Always store sensitive data in environment variables.

Enjoy building and customizing your new eCommerce platform!
