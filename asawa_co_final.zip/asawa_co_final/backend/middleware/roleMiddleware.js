/**
 * Middleware factory to enforce role‑based access control.  Pass in one or more
 * permitted role IDs (e.g. [1] for customers or [2] for admins).  The
 * authenticated user must have one of the specified roles; otherwise a 403
 * response is returned.
 *
 * Example: router.post('/admin', authenticate, permitRoles([2]), handler);
 */
export function permitRoles(roles = []) {
  return function (req, res, next) {
    if (!req.user || !roles.includes(req.user.role_id)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
}
