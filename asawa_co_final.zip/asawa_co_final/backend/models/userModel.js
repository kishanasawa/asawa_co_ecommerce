import pool from '../config/db.js';

/**
 * Insert a new user into the database.
 * @param {object} user {name, email, password, role_id}
 */
export async function createUser(user) {
  const { name, email, password, role_id } = user;
  const [result] = await pool.query(
    'INSERT INTO users (name, email, password, role_id) VALUES (?, ?, ?, ?)',
    [name, email, password, role_id]
  );
  return { id: result.insertId, ...user };
}

/**
 * Find a user by email.
 * @param {string} email
 */
export async function findUserByEmail(email) {
  const [rows] = await pool.query('SELECT * FROM users WHERE email = ? LIMIT 1', [email]);
  return rows[0] || null;
}

/**
 * Find a user by ID.
 * @param {number} id
 */
export async function findUserById(id) {
  const [rows] = await pool.query('SELECT * FROM users WHERE id = ? LIMIT 1', [id]);
  return rows[0] || null;
}
