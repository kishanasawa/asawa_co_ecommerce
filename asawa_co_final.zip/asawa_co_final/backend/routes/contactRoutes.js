import { Router } from 'express';
import pool from '../config/db.js';
import { sendMail } from '../config/mailer.js';

const router = Router();

// POST /api/contact
router.post('/', async (req, res) => {
  try {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ message: 'All fields are required' });
    }
    await pool.query(
      'INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)',
      [name, email, 'Contact Form', message]
    );
    // Send confirmation email to admin or user (optional)
    await sendMail({
      to: process.env.SMTP_USER,
      subject: 'New Contact Form Submission',
      html: `<p>You have received a new message from ${name} (${email})</p><p>${message}</p>`,
    });
    res.status(200).json({ message: 'Message sent' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to send message' });
  }
});

export default router;
