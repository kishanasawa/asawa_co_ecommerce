import { Router } from 'express';
import { authenticate } from '../middleware/authMiddleware.js';
import { permitRoles } from '../middleware/roleMiddleware.js';
import {
  placeOrder,
  listOrders,
  getOrder,
  changeStatus,
} from '../controllers/orderController.js';

const router = Router();

// Authenticated customer routes
router.post('/', authenticate, placeOrder);
router.get('/', authenticate, listOrders);
router.get('/:id', authenticate, getOrder);

// Admin route: change order status
router.put('/:id/status', authenticate, permitRoles([2]), changeStatus);

export default router;
