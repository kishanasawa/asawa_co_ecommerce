import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

const secret = process.env.JWT_SECRET || 'defaultsecret';
const expiresIn = process.env.JWT_EXPIRES_IN || '1d';

/**
 * Generate a JWT for a given payload.
 * @param {object} payload Data to embed in the token.
 * @returns {string} Signed JWT.
 */
export function generateToken(payload) {
  return jwt.sign(payload, secret, { expiresIn });
}

/**
 * Verify a JWT and return the decoded payload.
 * @param {string} token The JWT to verify.
 * @returns {object|null} The decoded payload or null if invalid.
 */
export function verifyToken(token) {
  try {
    return jwt.verify(token, secret);
  } catch (err) {
    return null;
  }
}
