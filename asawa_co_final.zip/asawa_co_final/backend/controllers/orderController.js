import { createOrder, getOrdersByUser, getOrderById, updateOrderStatus } from '../models/orderModel.js';

/**
 * POST /api/orders
 * Create a new order for the authenticated user.  Expects an array of items in
 * the request body, each with product_id, quantity and price.
 */
export async function placeOrder(req, res) {
  try {
    const userId = req.user.id;
    const { items } = req.body;
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: 'Order must contain at least one item' });
    }
    const orderId = await createOrder(userId, items);
    res.status(201).json({ orderId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to place order' });
  }
}

/**
 * GET /api/orders
 * Return all orders for the authenticated user.
 */
export async function listOrders(req, res) {
  try {
    const orders = await getOrdersByUser(req.user.id);
    res.json(orders);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to fetch orders' });
  }
}

/**
 * GET /api/orders/:id
 * Return a single order with its items.
 */
export async function getOrder(req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const order = await getOrderById(id);
    if (!order || order.user_id !== req.user.id) {
      return res.status(404).json({ message: 'Order not found' });
    }
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to fetch order' });
  }
}

/**
 * PUT /api/orders/:id/status
 * Update the status of an order (admin only).
 */
export async function changeStatus(req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const { status } = req.body;
    const updated = await updateOrderStatus(id, status);
    if (!updated) return res.status(404).json({ message: 'Order not found' });
    res.json({ message: 'Order status updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to update order' });
  }
}
