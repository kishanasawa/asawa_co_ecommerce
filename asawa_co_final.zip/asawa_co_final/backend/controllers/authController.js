import bcrypt from 'bcryptjs';
import { generateToken } from '../config/auth.js';
import { createUser, findUserByEmail } from '../models/userModel.js';

/**
 * Register a new user.  Returns a JWT on success.
 */
export async function register(req, res) {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email and password are required' });
    }
    // Check if user exists
    const existing = await findUserByEmail(email);
    if (existing) {
      return res.status(409).json({ message: 'User already exists' });
    }
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    // Default role_id = 1 (customer)
    const user = await createUser({ name, email, password: hashedPassword, role_id: 1 });
    const token = generateToken({ id: user.id, role_id: user.role_id });
    res.status(201).json({ token, user: { id: user.id, name, email, role_id: user.role_id } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Registration failed' });
  }
}

/**
 * Authenticate a user and return a JWT.
 */
export async function login(req, res) {
  try {
    const { email, password } = req.body;
    const user = await findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    const token = generateToken({ id: user.id, role_id: user.role_id });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role_id: user.role_id } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Login failed' });
  }
}
