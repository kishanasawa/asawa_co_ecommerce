import {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
} from '../models/productModel.js';

/**
 * GET /api/products
 * List products with optional pagination via query params (page, limit).
 */
export async function listProducts(req, res) {
  try {
    const page = parseInt(req.query.page || '1', 10);
    const limit = parseInt(req.query.limit || '20', 10);
    const offset = (page - 1) * limit;
    const products = await getAllProducts(limit, offset);
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to fetch products' });
  }
}

/**
 * GET /api/products/:id
 */
export async function getProduct(req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const product = await getProductById(id);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json(product);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to fetch product' });
  }
}

/**
 * POST /api/products
 * Create a new product (admin only).
 */
export async function addProduct(req, res) {
  try {
    const newProduct = await createProduct(req.body);
    res.status(201).json(newProduct);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to create product' });
  }
}

/**
 * PUT /api/products/:id
 * Update an existing product (admin only).
 */
export async function editProduct(req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const updated = await updateProduct(id, req.body);
    if (!updated) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to update product' });
  }
}

/**
 * DELETE /api/products/:id
 * Delete a product (admin only).
 */
export async function removeProduct(req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const removed = await deleteProduct(id);
    if (!removed) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product removed' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to delete product' });
  }
}
