import Head from 'next/head';
import Navbar from './Navbar';
import Footer from './Footer';

/**
 * Top-level layout component wrapping all pages.  Defines global meta tags and
 * includes the navigation bar and footer.  Children are rendered between
 * Navbar and Footer.
 */
export default function Layout({ children }) {
  return (
    <>
      <Head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>ASAWA and Co. – Pure &amp; Fresh</title>
        <meta
          name="description"
          content="ASAWA and Co. brings you fresh flours, masalas and dry fruits. We buy, we grind, we sell – pure and fresh."
        />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Navbar />
      <main className="min-h-screen pt-20 pb-16 bg-white text-gray-800">
        {children}
      </main>
      <Footer />
    </>
  );
}
