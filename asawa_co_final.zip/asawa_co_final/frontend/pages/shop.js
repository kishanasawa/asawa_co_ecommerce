import { useEffect, useState } from 'react';
import axios from 'axios';
import Link from 'next/link';

export default function Shop() {
  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(1);
  const limit = 12;

  useEffect(() => {
    async function fetchProducts() {
      try {
        const res = await axios.get(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'}/api/products?page=${page}&limit=${limit}`);
        setProducts(res.data);
      } catch (err) {
        console.error(err);
      }
    }
    fetchProducts();
  }, [page]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Shop Our Products</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <div key={product.id} className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-40 bg-gray-200 flex items-center justify-center">
              <span className="text-gray-400">Image</span>
            </div>
            <div className="p-4 flex flex-col">
              <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
              <p className="text-sm text-gray-600 flex-1 line-clamp-3">{product.description?.substring(0, 120)}</p>
              <p className="font-bold text-primary mt-2">₹{product.price}</p>
              <Link href={`/product/${product.id}`} className="mt-3 text-primary hover:underline text-sm">
                View Details
              </Link>
            </div>
          </div>
        ))}
      </div>
      <div className="flex justify-center mt-8 space-x-2">
        <button
          onClick={() => setPage((p) => Math.max(1, p - 1))}
          disabled={page === 1}
          className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300 disabled:opacity-50"
        >
          Previous
        </button>
        <button
          onClick={() => setPage((p) => p + 1)}
          className="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300"
        >
          Next
        </button>
      </div>
    </div>
  );
}
