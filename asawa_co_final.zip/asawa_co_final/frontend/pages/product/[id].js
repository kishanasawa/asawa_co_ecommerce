import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function ProductDetail() {
  const router = useRouter();
  const { id } = router.query;
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);

  useEffect(() => {
    if (!id) return;
    async function fetchProduct() {
      try {
        const res = await axios.get(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'}/api/products/${id}`);
        setProduct(res.data);
      } catch (err) {
        console.error(err);
      }
    }
    fetchProduct();
  }, [id]);

  const addToCart = () => {
    // In a full implementation, this would update global cart state
    alert(`Added ${qty} of ${product.name} to cart!`);
  };

  if (!product) return <div className="container mx-auto px-4 py-8">Loading...</div>;

  return (
    <div className="container mx-auto px-4 py-8 flex flex-col md:flex-row gap-8">
      <div className="md:w-1/2 bg-gray-200 h-64 flex items-center justify-center">
        <span className="text-gray-400">Image</span>
      </div>
      <div className="md:w-1/2">
        <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
        <p className="text-gray-700 mb-4">{product.description}</p>
        <p className="text-2xl font-bold text-primary mb-4">₹{product.price}</p>
        <div className="flex items-center space-x-4 mb-4">
          <label htmlFor="qty" className="text-sm font-medium">Quantity:</label>
          <input
            id="qty"
            type="number"
            min="1"
            value={qty}
            onChange={(e) => setQty(parseInt(e.target.value, 10))}
            className="w-20 border rounded-md p-1"
          />
        </div>
        <button
          onClick={addToCart}
          className="px-6 py-3 bg-primary text-white rounded-md hover:bg-secondary transition-colors"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}
